/****************************************************************************
Copyright (c) 2015-2016 Chukong Technologies Inc.
Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.

http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/
package com.cocos.game;

import static com.jujie.audiosdk.Constant.REQUEST_LOCATION_PERMISSION;
import static com.jujie.audiosdk.Constant.REQUEST_RECORD_AUDIO_ASR_PERMISSION;
import static com.jujie.audiosdk.Constant.REQUEST_RECORD_AUDIO_FSR_PERMISSION;

import android.Manifest;
import android.content.Intent;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.content.res.Configuration;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import androidx.annotation.NonNull;

import android.content.pm.PackageManager;
import android.widget.Toast;

import com.cocos.lib.JsbBridge;
import com.cocos.service.SDKWrapper;
import com.cocos.lib.CocosActivity;
import com.jujie.audiosdk.ASRManager;
import com.jujie.audiosdk.AddressManager;
import com.jujie.audiosdk.FSRManager;
import com.jujie.audiosdk.Helper;
import com.jujie.audiosdk.PaipaiCaptureActivity;
import com.jujie.audiosdk.TTSManager;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class AppActivity extends CocosActivity {
    private Context instance;
    private Map<String, Object> args;
    private TelephonyManager telephonyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 启动日志捕获
        LogcatCapture.startCapturing();

        // DO OTHER INITIALIZATION BELOW
        SDKWrapper.shared().init(this);

        instance = this;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            registerActivityLifecycleCallbacks(new AppLifecycleTracker());
        }

        // 注册生命周期回调
        ConnectivityMonitor.register(this, () -> {
            Log.d("AppActivity", "Network is available");
            if (!LogcatCapture.isAlive() || !LogcatCapture.isConnecting()) {
                LogcatCapture.connect();
            }

        });


        JsbBridge.setCallback(new JsbBridge.ICallback() {
            @Override
            public void onScript(String arg0, String arg1) {
                //TO DO
                Log.d("AppActivity","on script: "+arg0 +","+arg1);

                ///////////////////////////fsr////////////////////////

                if (arg0.equals("FSR") && arg1.equals("start")) {
                    Log.d("AppActivity", "FSR script: " + arg1);
                    FSRManager.start(instance);
                }
                if (arg0.equals("FSR") && arg1.equals("stop")) {
                    Log.d("AppActivity", "FSR script: " + arg1);
                    FSRManager.stop();
                }

                ///////////////////////////fsr////////////////////////
                if(arg0.equals("ASR") && arg1.startsWith("connect")){
                    Map<String, Object> result = parseCommand(arg1);

                    Log.d("AppActivity","parse command reslut" + result);

                    String func = (String) result.get("function");
                    Map<String, Object> param = (Map<String, Object>) result.get("param");

                    Log.d("AppActivity","ASR script: "+arg1);
                    ASRManager.start(instance, param);
                    args = param;
                }

                if(arg0.equals("ASR") && arg1.equals("close")){
                    Log.d("AppActivity","ASR script: "+arg1);
                    ASRManager.close();
                }

                if(arg0.equals("TTS")){
                    Log.d("AppActivity","TTS: "+arg1);
                }
                if(arg0.equals("TTS") && arg1.equals("connect")){
                    TTSManager.connect();
                    return;
                }

                if(arg0.equals("TTS") && arg1.equals("close")){
                    TTSManager.closeTTS();
                    return;
                }

                // tts send
                if(arg0.equals("TTS")){
                    try {
                        JSONObject jsonObject = new JSONObject(arg1);
                        Log.d("AppActivity", "===>"+jsonObject.toString());
                        String uid = jsonObject.getString("uid");
                        String text = jsonObject.getString("text");
                        TTSManager.send(uid, text);
                    } catch (JSONException e) {
                        Log.d("AppActivity", "parse json fail.");
                    }
                }

                // address start
                if(arg0.equals("ADDRESS") && arg1.equals("start")){
                    AddressManager.start(instance);
                }

                if(arg0.equals("QRCODE") && arg1.equals("scan")){

                    Log.d("AppActivity", "scan qrcode");
                    Intent intent = new Intent(instance, PaipaiCaptureActivity.class);
                    startActivityForResult(intent, 1002);
                }

                if(arg0.equals("DEVICE") && arg1.equals("info")){

                    String androidId = Settings.Secure.getString(
                            instance.getContentResolver(),
                            Settings.Secure.ANDROID_ID
                    );

                    Helper.uuid = androidId;

                    HashMap<String, String> map = new HashMap<>();
                    map.put("deviceId", androidId);

                    JSONObject jsonObject = new JSONObject(map);
                    String result = jsonObject.toString();

                    JsbBridge.sendToScript("DEVICEInfo", result);
                }


            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        Log.d("AppActivity", "onRequestPermissionsResult: requestCode = " + requestCode + ", permissions = " + Arrays.toString(permissions) + ", grantResults = " + Arrays.toString(grantResults));

        if (requestCode == REQUEST_RECORD_AUDIO_ASR_PERMISSION) {
            boolean recordAudioPermissionGranted = isPermissionGranted(permissions, grantResults[0], new String[]{android.Manifest.permission.RECORD_AUDIO});
//            boolean recordAudioPermissionGranted = false;
//            // 检查请求的权限是否被授予
//            for (int i = 0; i < permissions.length; i++) {
//                String permission = permissions[i];
//
//                if (permission.equals(android.Manifest.permission.RECORD_AUDIO)) {
//                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                        recordAudioPermissionGranted = true;
//                        break;
//                    } else {
//                        recordAudioPermissionGranted = false;
//                    }
//                }
//            }
//
//            Log.d("AppActivity", "recordAudioPermissionGranted = " + recordAudioPermissionGranted);

            if (recordAudioPermissionGranted) {
                // 权限已授予，执行需要该权限的操作
                ASRManager.start(this, args);

            } else {
                // 权限被拒绝，处理拒绝的情况
            }
        }else if(requestCode == REQUEST_RECORD_AUDIO_FSR_PERMISSION){
            boolean recordAudioPermissionGranted = isPermissionGranted(permissions, grantResults[0], new String[]{android.Manifest.permission.RECORD_AUDIO});
            if(recordAudioPermissionGranted){
                FSRManager.start(this);
            } else{
                // 权限被拒绝，处理拒绝的情况
                JSONObject error = new JSONObject();
                try {
                    error.put("code", 1); // 1 表示权限被拒绝
                    error.put("error", "permission denied");
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
                JsbBridge.sendToScript("FSRResult", error.toString());
            }


        }else if(requestCode == REQUEST_LOCATION_PERMISSION){
            Log.d("AppActivity", "check location permission");

            boolean locationPermissionGranted = false;
            // 检查请求的权限是否被授予
            // locationPermissionGranted = isPermissionGranted(permissions, grantResults, locationPermissionGranted);
            locationPermissionGranted = isPermissionGranted(permissions, grantResults[0], new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});

            Log.d("AppActivity", "locationPermissionGranted = " + locationPermissionGranted);

            if (locationPermissionGranted) {
                // 权限已授予，执行需要该权限的操作
                AddressManager.start(this);
            } else {
                // 权限被拒绝，处理拒绝的情况
            }

        }
    }

    private static boolean isPermissionGranted(String[] permissions, int grantResult, String[] expectedPermissions ) {
        for (int i = 0; i < permissions.length; i++) {
            String permission = permissions[i];

            if(Arrays.asList(expectedPermissions).contains(permission)){
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    return true;
                }
            };
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        SDKWrapper.shared().onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        SDKWrapper.shared().onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Workaround in https://stackoverflow.com/questions/16283079/re-launch-of-activity-on-home-button-but-only-the-first-time/16447508
        if (!isTaskRoot()) {
            return;
        }
        SDKWrapper.shared().onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("AppActivity", "onActivityResult: requestCode = " + requestCode + ", resultCode = " + resultCode + ", data = " + data);
        Log.d("AppActivity",  data.getStringExtra("SCAN_RESULT"));

        super.onActivityResult(requestCode, resultCode, data);
        SDKWrapper.shared().onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1002 && resultCode == RESULT_OK) {
            String scannedResult = data.getStringExtra("SCAN_RESULT");
            if(scannedResult == null){
                return;
            }
            // 处理扫描结果
            Toast.makeText(this, "扫码结果: " + scannedResult, Toast.LENGTH_SHORT).show();
            String jsonData = "{\"code\":\"" + scannedResult.replaceAll("\"", "'") + "\"}";
            JsbBridge.sendToScript("QRCODEResult", jsonData);
        }

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        SDKWrapper.shared().onNewIntent(intent);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        SDKWrapper.shared().onRestart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        SDKWrapper.shared().onStop();
    }

    @Override
    public void onBackPressed() {
        SDKWrapper.shared().onBackPressed();
        super.onBackPressed();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        SDKWrapper.shared().onConfigurationChanged(newConfig);
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        SDKWrapper.shared().onRestoreInstanceState(savedInstanceState);
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        SDKWrapper.shared().onSaveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onStart() {
        SDKWrapper.shared().onStart();
        super.onStart();
    }

    @Override
    public void onLowMemory() {
        SDKWrapper.shared().onLowMemory();
        super.onLowMemory();
    }

    public static Map<String, Object> parseCommand(String command) {
        // 定义结果 HashMap
        Map<String, Object> result = new HashMap<>();

        // 判断命令是否带参数
        if (command.contains("(") && command.contains(")")) {
            // 提取函数名（括号之前的部分）
            String functionName = command.substring(0, command.indexOf("(")).trim();
            result.put("function", functionName);

            // 提取括号中的参数
            String paramString = command.substring(command.indexOf("(") + 1, command.lastIndexOf(")")).trim();

            if (paramString.isEmpty()) {
                // 如果没有参数，将 param 设置为 null
                result.put("param", null);
            } else {
                // 如果有参数，解析为 HashMap
                result.put("param", parseParam(paramString));
            }
        }

        return result;
    }

    public static Map<String, Object> parseParam(String paramString) {
        // 去掉首尾的花括号
        paramString = paramString.trim();
        if (paramString.startsWith("{") && paramString.endsWith("}")) {
            paramString = paramString.substring(1, paramString.length() - 1).trim();
        }

        // 将单引号替换为双引号
        paramString = paramString.replace("'", "\"");

        Map<String, Object> paramMap = new HashMap<>();

        // 拆分每一对 key: value
        String[] pairs = paramString.split(",");
        for (String pair : pairs) {
            // 去掉空格
            pair = pair.trim();

            // 分割 key 和 value
            String[] keyValue = pair.split(":");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();

                // 如果值是数字，则转换为数字类型
                if (value.matches("-?\\d+(\\.\\d+)?")) {
                    // 数字类型
                    paramMap.put(key, parseNumber(value));
                } else {
                    // 其他值都作为字符串处理
                    paramMap.put(key, value.replace("\"", ""));
                }
            }
        }

        return paramMap;
    }

    // 解析数字
    private static Object parseNumber(String value) {
        if (value.contains(".")) {
            return Double.parseDouble(value);
        } else {
            return Integer.parseInt(value);
        }
    }


    public static void main(String[] args) {
        String command = "test()";
        Map<String, Object> result = parseCommand(command);
        System.out.println(result);

        command = "test(123)";
        result = parseCommand(command);
        System.out.println(result);

        command = "test(123, 'hello', 3.14)";
        result = parseCommand(command);
        System.out.println(result);

        command = "connect()";
        result = parseCommand(command);
        System.out.println(result);

        command = "connect({id:1, name:'hello', age: 29.39})";
        result = parseCommand(command);
        System.out.println(result);



    }


}
